create view course_table as
  select `data`.`takes`.`student_id`             AS `student_id`,
         `data`.`takes`.`course_id`              AS `course_id`,
         `data`.`takes`.`section_id`             AS `section_id`,
         `data`.`takes`.`semester`               AS `semester`,
         `data`.`takes`.`year`                   AS `year`,
         `data`.`sec_arrangement`.`time_slot_id` AS `time_slot_id`,
         `data`.`sec_arrangement`.`room_id`      AS `room_id`
  from (`data`.`takes` join `data`.`sec_arrangement` on ((
    (`data`.`takes`.`course_id` = `data`.`sec_arrangement`.`course_id`) and
    (`data`.`takes`.`section_id` = `data`.`sec_arrangement`.`section_id`) and
    (`data`.`takes`.`semester` = `data`.`sec_arrangement`.`semester`) and
    (`data`.`takes`.`year` = `data`.`sec_arrangement`.`year`))));


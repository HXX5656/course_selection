create view my_tests as
  select `data`.`takes`.`student_id` AS `student_id`,
         `data`.`takes`.`course_id`  AS `course_id`,
         `data`.`takes`.`section_id` AS `section_id`,
         `data`.`takes`.`semester`   AS `semester`,
         `data`.`takes`.`year`       AS `year`,
         `data`.`section`.`exam_id`  AS `exam_id`
  from (`data`.`takes` join `data`.`section` on (((`data`.`takes`.`course_id` = `data`.`section`.`course_id`) and
                                                  (`data`.`takes`.`section_id` = `data`.`section`.`section_id`) and
                                                  (`data`.`takes`.`semester` = `data`.`section`.`semester`) and
                                                  (`data`.`takes`.`year` = `data`.`section`.`year`))));


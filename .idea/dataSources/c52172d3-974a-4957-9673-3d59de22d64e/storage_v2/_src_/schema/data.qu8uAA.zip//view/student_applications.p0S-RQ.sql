create view student_applications as
  select `data`.`application`.`student_id` AS `student_id`,
         `data`.`application`.`course_id`  AS `course_id`,
         `data`.`application`.`section_id` AS `section_id`,
         `data`.`application`.`semester`   AS `semester`,
         `data`.`application`.`year`       AS `year`,
         `data`.`application`.`apply_time` AS `apply_time`,
         `data`.`application`.`reason`     AS `reason`,
         `data`.`application`.`status`     AS `status`
  from `data`.`application`;


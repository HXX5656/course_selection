create view application_manager as
  select `data`.`application`.`course_id`  AS `course_id`,
         `data`.`application`.`section_id` AS `section_id`,
         `data`.`application`.`semester`   AS `semester`,
         `data`.`application`.`year`       AS `year`,
         `data`.`application`.`app_id`     AS `app_id`,
         `data`.`application`.`reason`     AS `reason`,
         `data`.`application`.`status`     AS `status`,
         `data`.`application`.`apply_time` AS `apply_time`,
         `data`.`application`.`student_id` AS `student_id`,
         `data`.`teaches`.`teacher_id`     AS `teacher_id`
  from (`data`.`application` join `data`.`teaches` on ((
    (`data`.`application`.`course_id` = `data`.`teaches`.`course_id`) and
    (`data`.`application`.`section_id` = `data`.`teaches`.`section_id`) and
    (`data`.`application`.`semester` = `data`.`teaches`.`semester`) and
    (`data`.`application`.`year` = `data`.`teaches`.`year`))));


create view student_grades as
  select `data`.`takes`.`student_id` AS `student_id`,
         `data`.`takes`.`course_id`  AS `course_id`,
         `data`.`takes`.`section_id` AS `section_id`,
         `data`.`takes`.`semester`   AS `semester`,
         `data`.`takes`.`year`       AS `year`,
         `data`.`takes`.`grade`      AS `grade`
  from `data`.`takes`;


create view membership as
  select `data`.`takes`.`course_id`      AS `course_id`,
         `data`.`takes`.`section_id`     AS `section_id`,
         `data`.`takes`.`semester`       AS `semester`,
         `data`.`takes`.`year`           AS `year`,
         `data`.`student`.`student_id`   AS `student_id`,
         `data`.`student`.`student_name` AS `student_name`,
         `data`.`student`.`enter_time`   AS `enter_time`,
         `data`.`student`.`gradu_time`   AS `gradu_time`,
         `data`.`student`.`student_dep`  AS `student_dep`,
         `data`.`takes`.`grade`          AS `grade`,
         `data`.`teaches`.`teacher_id`   AS `teacher_id`
  from ((`data`.`student` join `data`.`takes` on ((`data`.`student`.`student_id` =
                                                   `data`.`takes`.`student_id`))) join `data`.`teaches` on ((
    (`data`.`takes`.`course_id` = `data`.`teaches`.`course_id`) and
    (`data`.`takes`.`section_id` = `data`.`teaches`.`section_id`) and
    (`data`.`takes`.`semester` = `data`.`teaches`.`semester`) and (`data`.`takes`.`year` = `data`.`teaches`.`year`))));

